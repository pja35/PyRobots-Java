print "Bonjour, je suis un script python, on m'a donner la telecommande d'un tank, je suis content ^^, mais comme je sais pas m'en servir, je vais tourner en rond."

while True:
	tank.moveForward()
