print "Ceci est du texte python que j'envoie au java! Script2"
tank.moveBackward();
